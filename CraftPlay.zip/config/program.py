import webview

content = """

<body style="padding: 0; margin: 0; background-image: url(https://www.nssv.pl/img/background.png);   background-size: cover;">

    <script>
        function sendName(){
            document.getElementById("name").value = "";
        }
    </script>

    <div style="text-align: center; height: 100%;">
        <div style="height: 50%;"></div>
        <input id="name" placeholder="Nick" style="background-color: #4285f4; border: none; font-size: 19px;" type="text">
        <br><br>
        <button onclick="sendName()" style="background-color: #4285f4; border: none; font-size: 21px;">Losuj</button>
    </div>
    
</body>
"""

webview.create_window('Woah dude!', html=content)
webview.start()
