import requests
import sys


myfile = requests.get(sys.argv[1])

open(sys.argv[2], 'wb').write(myfile.content)
print("done")